﻿function calcGrade() {
    var assignment = document.getElementById('hw').value / 100;
    var group = document.getElementById('groupProject').value / 100;
    var quiz = document.getElementById('quiz').value / 100;
    var exam = document.getElementById('exam').value / 100;
    var intex = document.getElementById('intex').value / 100;
    var letterGrade;

    assignment = assignment * (2000 * .5);
    group = group * (2000 * .1);
    quiz = quiz * (2000 * .1);
    exam = exam * (2000 * .2);
    intex = intex * (2000 * .1);

    totalPoints = assignment + group + quiz + exam + intex;
    gradePct = totalPoints / 2000;
    gradePct = gradePct * 100;

    if (gradePct >= 94) {
        letterGrade = 'A';
    }
    else if (gradePct < 94 && gradePct >= 90) {
        letterGrade = 'A-'
    }
    else if (gradePct < 90 && gradePct >= 87) {
        letterGrade = 'B+'
    }
    else if (gradePct < 87 && gradePct >= 84) {
        letterGrade = 'B'
    }
    else if (gradePct < 84 && gradePct >= 80) {
        letterGrade = 'B-'
    }
    else if (gradePct < 80 && gradePct >= 77) {
        letterGrade = 'C+'
    }
    else if (gradePct < 77 && gradePct >= 74) {
        letterGrade = 'C'
    }
    else if (gradePct < 74 && gradePct >= 70) {
        letterGrade = 'C-'
    }
    else if (gradePct < 70 && gradePct >= 67) {
        letterGrade = 'D+'
    }
    else if (gradePct < 67 && gradePct >= 64) {
        letterGrade = 'D'
    }
    else if (gradePct < 64 && gradePct >= 60) {
        letterGrade = 'D-'
    }
    else  {
        letterGrade = 'E'
    }

    alert('You have a ' + letterGrade + ' with a ' + gradePct + '%') 

}


