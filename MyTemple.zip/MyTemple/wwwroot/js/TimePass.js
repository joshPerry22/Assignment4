﻿
    function AssignTime(time) {
        var timeWanted = 0;
        timeWanted = parseInt(time);
        if (timeWanted > 12) {
        timeWanted = timeWanted - 12;
            document.getElementById("timeSelected").value = timeWanted + "PM";
            break;
        }
        

        if (timeWanted == 12) {
            document.getElementById("timeSelected").value = timeWanted + "PM";
            break;
        }
        
        document.getElementById("timeSelected").value = timeWanted + "AM";

    }
