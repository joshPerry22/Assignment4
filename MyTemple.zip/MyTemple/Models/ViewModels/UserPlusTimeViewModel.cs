﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyTemple.Models.ViewModels
{
    public class UserPlusTimeViewModel
    {

    }
}
