﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyTemple.Models
{
    public class TimeModelContext : DbContext
    {
        public TimeModelContext(DbContextOptions<TimeModelContext> options) : base(options)
        {

        }

        public DbSet<TimeModel> TimeMod { get; set; }
    }
}
