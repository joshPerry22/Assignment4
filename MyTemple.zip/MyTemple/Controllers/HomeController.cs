﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyTemple.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MyTemple.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        

        public HomeController()
        {
            
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Times()
        {
            return View();
        }

       [HttpPost]
       public IActionResult Times(TimeModel timeM)
        {
            return View("UserInput", timeM);
        }

        [HttpGet]
        public IActionResult UserInput ()
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserInput(UserInput user)
        {
            return View("Index", user);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
